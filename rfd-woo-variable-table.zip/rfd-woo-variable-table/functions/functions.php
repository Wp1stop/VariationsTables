<?php
/**
 * Main file for additional functions
 *
 * @link       https://cimba.blog/
 * @since      0.9.0
 *
 * @package    RFD\Woo_Variable_Table
 *
 * phpcs:ignoreFile
 */

require_once __DIR__ . DIRECTORY_SEPARATOR . 'math.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'woo.php';
