# Release 1.0.6

Fixes:

* Auto-draft new posts when new variable products are created
* Auto-publish new products after first save of product post

# Release 1.0.5

Fixes:

* Trigger process to alter product type and create variations even when admin-ajax is in use.

# Release 1.0.4

Fixes:

* Problem with Dokan Pro adding new product not being converted to variable if simple.

# Release 1.0.3

Fixes:

* Problem with Dokan Pro where Attributes and Variation Save Variations process had higher priority causing wrong data
  to be saved.

# Release 1.0.2

Fixes:

* Problem with prices being wrongly saved.

# Release 1.0.1

Fixes:

* Core update to 2.2.1

# Release 1.0.0

Initial release