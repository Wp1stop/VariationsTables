# RFD Woo Variable Tables

Edit your variable products with ease using table variable products.

Set default product type and, if variable product type is selected, selected default variations to be automatically
created after product in that category is created.

Adds a table for Dokan Pro when editing product to improve the UX for users and to allow editing of selected variation
elements in a table avoiding usage of accordion.